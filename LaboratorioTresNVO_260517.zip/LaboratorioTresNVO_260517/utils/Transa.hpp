 enum class Transa { Venta, Alquiler };
