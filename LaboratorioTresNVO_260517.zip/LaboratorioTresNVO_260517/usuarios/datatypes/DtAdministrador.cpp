
#include "DtAdministrador.hpp"
#include "DtUsuario.hpp"

  DtAdministrador :: DtAdministrador(): DtUsuario(){

  }

		virtual ~DtAdministrador(){

    }
