#include"DtPropiedad.hpp"
#include"DtApartamento.hpp"unsigned int m_Counter
DtApartamento::DtApartamento():DtPropiedad()
{

}
