#include "Fabrica.hpp"

Fabrica::Fabrica(){ }

Fabrica::~Fabrica(){
    //delete this;
}


Sistema* Fabrica::getSistema(){
    return new Sistema();
}