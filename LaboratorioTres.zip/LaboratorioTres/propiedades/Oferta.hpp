#ifndef OFERTA_HPP
#define OFERTA_HPP

#include "../utils/Transa.hpp"
#include "./datatypes/DtOferta.hpp"

using namespace std;

class Oferta {

    public:
        Oferta();
		Oferta(DtOferta);
        // FIXME
        float getPrecio() { return this->precio; }
        void setPrecio(float prec) { this->precio = prec; }
        Transa getTipo() { return this->tipo; }
        Transa setTipo(Transa tipo) { this->tipo = tipo; }
        

        // bool operator == (Oferta*);

      // toDataType
     DtOferta toDataType();

		// Destructor

		virtual ~Oferta();

    private:
        float precio;
        Transa tipo;
};

#endif //OFERTA_HPP
