#include "Edificio.hpp"

Edificio::Edificio()
{
    this->nombre="";
    this->cantPisos=0;
    this->gastosComunes=0.0;
}

Edificio::Edificio(DtEdificio edif)
{
    this->nombre=edif.getNombre();
    this->cantPisos=edif.getCantPisos();
    this->gastosComunes=edif.getGastosComunes();
}

DtEdificio Edificio::toDataType()
{
    DtEdificio edif;
    edif.setNombre(this->getNombre());
    edif.setCantPisos(this->getCantPisos());
    edif.setGastosComunes(this->getGastosComunes());
    return edif;
}
Edificio::~Edificio()
{
    //dtor
}
