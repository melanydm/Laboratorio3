#ifndef EDIFICIO_HPP
#define EDIFICIO_HPP

#include "./datatypes/DtEdificio.hpp"

class Edificio
{
    public:
        Edificio();
        Edificio(DtEdificio);
        virtual ~Edificio();

        string getNombre() { return this->nombre; }
        void setNombre(string val) { this->nombre = val; }
        int getCantPisos() { return this->cantPisos; }
        void setCantPisos(int val) { this->cantPisos = val; }
        float getGastosComunes() { return this->gastosComunes; }
        void setGastosComunes(float val) { this->gastosComunes = val; }

        DtEdificio toDataType();

    private:
        string nombre;
        int cantPisos;
        float gastosComunes;
};

#endif // EDIFICIO_HPP
