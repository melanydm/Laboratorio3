#include "DtDepartamento.hpp"

using namespace std;

DtDepartamento::DtDepartamento()
{
    id="";
    nombre="";
}

DtDepartamento toDataType(){
    DtDepartamento oDtDepartamento;
    return oDtDepartamento;
}
/*
istream& operator>>(istream&, DtDepartamento dtd){
    int id = 0;
    string nombre = "";

    int i = 0;
	string s = " ";
	while ( s != "\n"  && i < 3 ){
		in >> setw(1) >> s;
		if (s == ",")
			i++;
		if (i == 0)
			id = id * 10 + (int)s;
		else if (i == 1)
			nombre = nombre + s;
	}

    dtd->setId(id);
    dtd->setNombre(nombre);
}

ostream& operator<<(ostream&, DtDepartamento dtd) {
    out << "Id:" << this->id << "\r\n"
        << "Nombre:" << this->nombre;
    return out;
}
*/
