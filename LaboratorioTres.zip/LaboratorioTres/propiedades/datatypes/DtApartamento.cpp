
#include"DtApartamento.hpp"

DtApartamento::DtApartamento():DtPropiedad()
{

}
