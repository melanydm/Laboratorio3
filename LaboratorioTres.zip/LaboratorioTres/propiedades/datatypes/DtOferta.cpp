#include "DtOferta.hpp"

// Setters
Transa DtOferta::getTipo() { return this->tipo; }
float DtOferta::getPrecio() { return this->precio; }

// Getters
void DtOferta::setTipo(Transa tipo) { this->tipo = tipo; }
void DtOferta::setPrecio(float precio) { this->precio = precio; }

istream& operator>>(istream&, DtOferta dtd){
    Transa tipo = Venta;
    float precio = 0;

    int i = 0;
	string s = " ";
	while ( s == "\n"  && i < 2 ){
		cin >> setw(1) >> s;
		if (s == ",")
			i++;
        // Asumimos que es una venta. Al ingresar una venta podremos poner cualquier cosa o simplemente una coma.
        if (i == 0 && s == "0") {
            tipo = Alquiler;
        }
		else if (i == 1){
             // FIXME
             //std::string::size_type sz;   // alias of size_t
             //int i_dec = std::stoi (s,&sz);
             //precio = precio * 10 + (int)s;
             precio = precio * 10;
        }
			
	}

    dtd.setTipo(tipo);
    dtd.setPrecio(precio);
}

ostream& operator<<(ostream&, DtOferta dtd) {
    cout << "Tipo:" << dtd.getTipo() << "\r\n"
        << "Precio:" << dtd.getPrecio();
    return cout;
}
