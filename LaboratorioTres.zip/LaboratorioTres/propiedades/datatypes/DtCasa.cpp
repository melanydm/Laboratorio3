#include"DtCasa.hpp"

//ctor
DtCasa::DtCasa():DtPropiedad(){
    this->mts_espaciosVerdes=1;
}
   //getters
int DtCasa::getMts_espaciosVerdes(){
    return this->mts_espaciosVerdes;
}
    //setters
void DtCasa::setMts_espaciosVerdes(int aux)
{
    this->mts_espaciosVerdes=aux;
}
