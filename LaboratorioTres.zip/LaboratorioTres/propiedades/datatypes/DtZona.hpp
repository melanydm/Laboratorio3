#ifndef DT_ZONA_HPP
#define DT_ZONA_HPP

#include <string>
#include <iostream>

using namespace std;

class DtZona  {
	private:
		string nombre;
		string codigo;

    public:
        DtZona();

		// Operators

		//virtual bool operator == (DtZona) = 0;

		// Getters
		string getCodigo();
		string getNombre();
	
		// Setters
		void setCodigo(string);
		void setNombre(string);
	
		// Destructor

		virtual ~DtZona();
};
  //istream& operator>>(istream&, DtZona);
  //ostream& operator<<(ostream&, DtZona);

#endif //DT_ZONA_HPP
