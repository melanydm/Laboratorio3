
#include "Oferta.hpp"

    Oferta::Oferta(){

    }
	 Oferta::Oferta(DtOferta oDtOferta){
    this->precio=oDtOferta.getPrecio();
    this->tipo=oDtOferta.getTipo();
}             
                         
DtOferta Oferta::toDataType(){
   DtOferta oDtOferta;
   oDtOferta.setPrecio(this->getPrecio());
   return oDtOferta;
}

// bool operator == (Oferta* oOferta){
//   if(oOferta->getPrecio() == this->getPrecio())
//      return true;
//  return false;
// }

Oferta ::~Oferta(){
    
}
