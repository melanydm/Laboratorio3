
#include "DtAdministrador.hpp"
#include "DtUsuario.hpp"

  DtAdministrador :: DtAdministrador(): DtUsuario(){

  }

		 DtAdministrador :: ~DtAdministrador(){

    }
