
#include "DtUsuario.hpp"

    DtUsuario :: DtUsuario(){
      this->email = "";
      this->contrasenia = "";
    }

    DtUsuario :: DtUsuario(string email,string contrasenia){
      this->email = email;
      this->contrasenia = contrasenia;
    }

		string DtUsuario :: getEmail(){
      return this->email;
    }
    string DtUsuario :: getContrasenia(){
      return this->contrasenia;
    }
    void DtUsuario :: setEmail(string email){
      this->email = email;
    }
    void DtUsuario :: setContrasenia(string contrasenia){
      this->contrasenia = contrasenia;
    }

		//  bool operator == (DtUsuario oUsuario){
    //    if(oUsuario.getEmail() == this->email)
    //       return true;
    //   return false;
    //  }
    //  }


		DtUsuario :: ~DtUsuario(){

    }
