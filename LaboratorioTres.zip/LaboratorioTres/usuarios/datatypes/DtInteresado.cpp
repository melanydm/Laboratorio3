
#include "DtInteresado.hpp"
#include "DtUsuario.hpp"


    DtInteresado :: DtInteresado(): DtUsuario(){
      this->nombre = "";
      this->apellido = "";
      this->edad = 0;
    }


        // geters seters
		string DtInteresado :: getNombre(){
      return this->nombre;
    }
    string DtInteresado :: getApellido(){
      return this->apellido;
    }
    int DtInteresado :: getEdad(){
      return this->edad;
    }
    void DtInteresado :: setNombre(string nombre){
      this->nombre = nombre;
    }
    void DtInteresado :: setApellido(string apellido){
      this->apellido = apellido;
    }
    void DtInteresado :: setEdad(int edad){
      this->edad = edad;
    }

		// Destructor

		DtInteresado :: ~DtInteresado(){

    }
