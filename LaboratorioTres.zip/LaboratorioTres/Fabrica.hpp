#include "Sistema.hpp"

class Fabrica {
  public:
    Fabrica();

    virtual  ~Fabrica();


    virtual Sistema* getSistema();
};
