#ifndef Transa_HPP
#define	Transa_HPP

enum transa{
    Venta, Alquiler
};

typedef enum transa Transa;

#endif	/* Transa_HPP */